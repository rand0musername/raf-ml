# TODO popuniti kodom za problem 3c
