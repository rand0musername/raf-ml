# TODO popuniti kodom za problem 2a
