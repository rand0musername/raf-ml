# TODO popuniti kodom za problem 3b
