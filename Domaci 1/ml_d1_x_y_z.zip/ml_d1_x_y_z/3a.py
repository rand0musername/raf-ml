# TODO popuniti kodom za problem 3a
