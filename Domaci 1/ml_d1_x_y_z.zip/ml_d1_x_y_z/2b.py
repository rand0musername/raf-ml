# TODO popuniti kodom za problem 2b
